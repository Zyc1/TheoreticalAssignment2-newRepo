public class DepositSlot
{
  // indicates whether envelope was received (always returns true,
  // because this is only a software simulation of a real deposit slot)
  public int isEnvelopeReceived ()
  {
    return 1;		// deposit envelope was received
  }				// end method isEnvelopeReceived
}				// end class DepositSlot
